<?php include 'dbcon.php';>

<html>
<body>

<p> Hello <?php echo $_POST['fname2']; ?> ! </p>

<?php

$fname2=$_POST['fname2'];
$lname2=$_POST['lname2'];
$add2=$_POST['add2'];

</html>
</body>