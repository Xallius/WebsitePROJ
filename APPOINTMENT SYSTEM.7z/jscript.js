 $('#btnNext').on('click', function() {
    $('#tabtab a[href="#menu1"]').tab('show');
});